# Changelog

## 0.9.0 (2015-02-04)

- Add changelog
- Finish up py3k and unicode support
- Unicode should work on OSX, Windows and Linux
- Some tests have been added

